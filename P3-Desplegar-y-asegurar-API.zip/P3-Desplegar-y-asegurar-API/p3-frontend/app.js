// ------------------------------------------------------------------
// CONFIGURACIÓN: cambia URL_RENDER por la URL que te asignó Render.
// ------------------------------------------------------------------
const URL_RENDER = "https://p2-api-productos.onrender.com";
const URL_LOCAL = "http://localhost:3000";

// Si la página se abre con Live Server (localhost / 127.0.0.1) usa la API local;
// publicada en GitHub Pages usa la API de Render.
const ES_LOCAL = ["localhost", "127.0.0.1"].includes(location.hostname);
const API_URL = (ES_LOCAL ? URL_LOCAL : URL_RENDER) + "/api/productos";
const API_KEY = "eq4x7b-781d1d69525dcffe6e"; // solo para la práctica (ver limitación en README)

const mensaje = document.getElementById("mensaje");
const resultados = document.getElementById("resultados");
const form = document.getElementById("formProducto");
const btnGuardar = document.getElementById("btnGuardar");
const btnCancelar = document.getElementById("btnCancelar");

let productosActuales = [];
let idEditando = null; // null = agregando; número = editando ese producto

// Evita que un nombre con etiquetas HTML se ejecute dentro de la página.
function escaparHTML(texto) {
  return String(texto).replace(/[&<>"']/g, c => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"
  }[c]));
}

async function listar() {
  mensaje.textContent = "Cargando...";
  try {
    const respuesta = await fetch(API_URL);
    if (!respuesta.ok) throw new Error(`código ${respuesta.status}`);
    const productos = await respuesta.json();
    productosActuales = productos;
    resultados.innerHTML = productos.map(p => `
      <article class="tarjeta">
        <h3>${escaparHTML(p.nombre)}</h3>
        <p>Precio: $${p.precio} · Stock: ${p.stock}</p>
        <div class="acciones">
          <button data-accion="editar" data-id="${p.id}" class="secundario">Editar</button>
          <button data-accion="eliminar" data-id="${p.id}">Eliminar</button>
        </div>
      </article>`).join("");
    mensaje.textContent = `${productos.length} producto(s)`;
  } catch (error) {
    mensaje.textContent = "No se pudo conectar con la API: " + error.message;
  }
}

// POST, PUT y DELETE llevan el token en el encabezado x-api-key.
async function peticionProtegida(url, metodo, datos) {
  const respuesta = await fetch(url, {
    method: metodo,
    headers: { "Content-Type": "application/json", "x-api-key": API_KEY },
    body: datos ? JSON.stringify(datos) : undefined
  });
  if (!respuesta.ok) {
    const error = await respuesta.json();
    throw new Error(error.errores ? error.errores.join(", ") : error.error);
  }
}

function salirDeEdicion() {
  idEditando = null;
  form.reset();
  btnGuardar.textContent = "Agregar";
  btnCancelar.hidden = true;
}

form.addEventListener("submit", async (e) => {
  e.preventDefault();
  const datos = {
    nombre: document.getElementById("txtNombre").value.trim(),
    precio: Number(document.getElementById("txtPrecio").value),
    stock: parseInt(document.getElementById("txtStock").value)
  };
  try {
    if (idEditando === null) {
      await peticionProtegida(API_URL, "POST", datos);
    } else {
      await peticionProtegida(`${API_URL}/${idEditando}`, "PUT", datos); // reto: Editar con PUT
    }
    salirDeEdicion();
    listar();
  } catch (error) {
    mensaje.textContent = "No se pudo guardar: " + error.message;
  }
});

btnCancelar.addEventListener("click", salirDeEdicion);

resultados.addEventListener("click", async (e) => {
  if (e.target.tagName !== "BUTTON") return;
  const id = Number(e.target.dataset.id);

  if (e.target.dataset.accion === "editar") {
    const p = productosActuales.find(prod => prod.id === id);
    document.getElementById("txtNombre").value = p.nombre;
    document.getElementById("txtPrecio").value = p.precio;
    document.getElementById("txtStock").value = p.stock;
    idEditando = id;
    btnGuardar.textContent = "Guardar cambios";
    btnCancelar.hidden = false;
    mensaje.textContent = `Editando: ${p.nombre}`;
    return;
  }

  try {
    await peticionProtegida(`${API_URL}/${id}`, "DELETE");
    if (idEditando === id) salirDeEdicion();
    listar();
  } catch (error) {
    mensaje.textContent = "No se pudo eliminar: " + error.message;
  }
});

listar();
