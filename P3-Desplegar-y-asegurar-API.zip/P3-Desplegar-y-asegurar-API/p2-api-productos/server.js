// P3 · Desplegar y asegurar la API en la nube
// Paso 1: cargar las variables del archivo .env (en Render se configuran en el panel).
require("dotenv").config();
const express = require("express");
const cors = require("cors");

const app = express();
const PORT = process.env.PORT || 3000;

// Paso 2: CORS restringido. Solo los orígenes listados en ORIGEN_PERMITIDO
// (separados por comas) pueden consumir la API desde un navegador.
const ORIGENES = (process.env.ORIGEN_PERMITIDO || "")
  .split(",")
  .map(origen => origen.trim())
  .filter(Boolean);

app.use(cors({ origin: ORIGENES })); // solo estas páginas pueden usar la API
app.use(express.json());

// Los datos viven en memoria y se restablecen al reiniciar el servidor.
let productos = [
  { id: 1, nombre: "Teclado", precio: 350, stock: 10 },
  { id: 2, nombre: "Mouse", precio: 180, stock: 25 }
];
let siguienteId = 3;

// Paso 3: middleware que exige el token en el encabezado x-api-key.
// Se agrega como segundo parámetro solo en las rutas que modifican datos.
function requiereToken(req, res, next) {
  // Si API_KEY no está configurada, se rechaza todo: así un olvido en la
  // configuración no deja la API abierta (sin esta revisión,
  // undefined !== undefined sería false y la petición pasaría).
  if (!process.env.API_KEY || req.get("x-api-key") !== process.env.API_KEY) {
    return res.status(401).json({ error: "Token inválido o ausente" });
  }
  next(); // el token es correcto, continúa a la ruta
}

function validar(datos) {
  const errores = [];
  if (!datos || typeof datos !== "object" || Array.isArray(datos)) {
    return ["El cuerpo debe ser un objeto JSON"];
  }
  if (!datos.nombre || typeof datos.nombre !== "string") {
    errores.push("nombre es obligatorio y debe ser texto");
  }
  if (typeof datos.precio !== "number" || !Number.isFinite(datos.precio) || datos.precio < 0) {
    errores.push("precio debe ser un número mayor o igual a cero");
  }
  if (!Number.isInteger(datos.stock) || datos.stock < 0) {
    errores.push("stock debe ser un entero mayor o igual a cero");
  }
  return errores;
}

app.get("/", (req, res) => {
  res.status(200).json({ mensaje: "API de productos funcionando" });
});

// Reto opcional: ruta de salud para revisar que el servicio está activo.
app.get("/api/salud", (req, res) => {
  res.status(200).json({ estado: "ok" });
});

// Rutas GET: públicas.
app.get("/api/productos", (req, res) => {
  res.status(200).json(productos);
});

app.get("/api/productos/:id", (req, res) => {
  const id = Number(req.params.id);
  const producto = productos.find((p) => p.id === id);
  if (!producto) {
    return res.status(404).json({ error: `No existe el producto ${req.params.id}` });
  }
  return res.status(200).json(producto);
});

// Rutas de escritura: protegidas con requiereToken.
app.post("/api/productos", requiereToken, (req, res) => {
  const errores = validar(req.body);
  if (errores.length > 0) {
    return res.status(400).json({ errores });
  }
  const { nombre, precio, stock } = req.body;
  const nuevo = { id: siguienteId++, nombre, precio, stock };
  productos.push(nuevo);
  return res.status(201).json(nuevo);
});

app.put("/api/productos/:id", requiereToken, (req, res) => {
  const id = Number(req.params.id);
  const indice = productos.findIndex((p) => p.id === id);
  if (indice === -1) {
    return res.status(404).json({ error: `No existe el producto ${req.params.id}` });
  }
  const errores = validar(req.body);
  if (errores.length > 0) {
    return res.status(400).json({ errores });
  }
  const { nombre, precio, stock } = req.body;
  productos[indice] = { id, nombre, precio, stock };
  return res.status(200).json(productos[indice]);
});

app.delete("/api/productos/:id", requiereToken, (req, res) => {
  const id = Number(req.params.id);
  const existe = productos.some((p) => p.id === id);
  if (!existe) {
    return res.status(404).json({ error: `No existe el producto ${req.params.id}` });
  }
  productos = productos.filter((p) => p.id !== id);
  return res.status(204).send();
});

// Debe ir después de todas las rutas válidas.
app.use((req, res) => {
  res.status(404).json({ error: "Ruta no encontrada" });
});

app.listen(PORT, () => {
  console.log(`Servidor en http://localhost:${PORT}`);
  console.log(`Orígenes permitidos: ${ORIGENES.join(", ") || "(ninguno)"}`);
});
